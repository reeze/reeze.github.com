<?php

/**
 * Tests for get_var_name();
 */


// Inner class call
class A {
	public $var = '';
	public function __construct() {
		//global $foo;
		$c = "100";
		$d = 10;
		echo get_var_name($r=strlen($c)) . "\n";
	}

	public static function test() {
		echo get_var_name($cd=10) . "\n";
		echo get_var_name($cc=$d=strlen('aa')) . "\n";
	}

}

//A::test();

$foo = $bar = 10;
$a = new A();


$fox = "JUST_TEST";

//echo get_var_name($x);

//echo var_export($GLOBAL);
