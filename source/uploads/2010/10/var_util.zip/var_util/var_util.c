/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_var_util.h"

/* If you declare any globals in php_var_util.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(var_util)
*/

/* True global resources - no need for thread safety here */
static int le_var_util;

/* {{{ var_util_functions[]
 *
 * Every user visible function must have an entry in var_util_functions[].
 */
const zend_function_entry var_util_functions[] = {
	PHP_FE(get_var_name,	NULL)
	{NULL, NULL, NULL}	/* Must be the last line in var_util_functions[] */
};
/* }}} */

/* {{{ var_util_module_entry
 */
zend_module_entry var_util_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"var_util",
	var_util_functions,
	PHP_MINIT(var_util),
	PHP_MSHUTDOWN(var_util),
	PHP_RINIT(var_util),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(var_util),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(var_util),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_VAR_UTIL
ZEND_GET_MODULE(var_util)
#endif

/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("var_util.global_value",      "42", PHP_INI_ALL, OnUpdateLong, global_value, zend_var_util_globals, var_util_globals)
    STD_PHP_INI_ENTRY("var_util.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_var_util_globals, var_util_globals)
PHP_INI_END()
*/
/* }}} */

/* {{{ php_var_util_init_globals
 */
/* Uncomment this function if you have INI entries
static void php_var_util_init_globals(zend_var_util_globals *var_util_globals)
{
	var_util_globals->global_value = 0;
	var_util_globals->global_string = NULL;
}
*/
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(var_util)
{
	/* If you have INI entries, uncomment these lines 
	REGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(var_util)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(var_util)
{
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(var_util)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(var_util)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "var_util support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */


/* {{{ get_var_name
 *
 * 这个扩展要求PHP >= 5.1
 * 因为依赖PHP 5.1引入的compiled variable
 *
 * 在PHP空间导出一个get_var_name函数.
 * echo get_var_name($var_name);   // expect: var_name
 * echo get_var_name($lineno=100); // expect: lineno
 */
PHP_FUNCTION(get_var_name)
{
	int len;
	char *strg = "";

	if(ZEND_NUM_ARGS() < 1) {
		return;
	}

	/* 显示作用域内所有的编译变量
	int i;
	zend_compiled_variable *vars = EG(active_op_array)->vars;
	for(i=0; i < EG(active_op_array)->last_var; ++i) { // last_var 最后一个编译变量的索引
		spprintf(&strg, 0, "%s\nVar:%s\n", strg, EG(active_op_array)->vars[i].name);
		++vars;
	}
	*/

	zend_op *pre_opline_ptr = *EG(opline_ptr);
	pre_opline_ptr--;

	// 支持这类的调用:  get_var_name($a="VALUE"); // expect: a
	// 这里增加在赋值的情况下也能正确返回变量的名字的处理方法, 如果方法参数是赋值的的话, 编译的OPCODE 中SEND_VAR之前将会
	// 有一个ZEND_ASSIGN 操作, 并且ZEND_ASSIGN操作的返回值被使用.比如: $c = $d + 1;  $d + 1的返回值就被使用了. 就可以确认
	// 是赋值的调用方式
	zend_op *pre_pre_online_ptr = pre_opline_ptr - 1;
	if(pre_pre_online_ptr && pre_pre_online_ptr->opcode == ZEND_ASSIGN && !(pre_pre_online_ptr->result.u.EA.type & EXT_TYPE_UNUSED)) {
		// 通过赋值之前的zend_op来获取变量信息
		pre_opline_ptr = pre_pre_online_ptr;
	}

	int index;
	// 比如get_var_name($name); 这时SEND_VAR OPCODE的op1操作数类型就是IS_CV 也就是IS Compiled Variable
	// 只有compiled variable才是直接存储索引的. PHP >= 5.1
	if(pre_opline_ptr->op1.op_type == IS_CV) {
		index = pre_opline_ptr->op1.u.var;
	}
	else {
		// 请参考VLD的源代码  $VLD_SRC/srm_oparray.c LINE:320 vld_dump_znode函数
		index = pre_opline_ptr->op1.u.var / sizeof(temp_variable);	
	}

	zend_compiled_variable var = EG(active_op_array)->vars[index];
	len = spprintf(&strg, 0, "%s", strg, var.name);

	RETURN_STRINGL(strg, len, 0);
}
/* }}} */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
