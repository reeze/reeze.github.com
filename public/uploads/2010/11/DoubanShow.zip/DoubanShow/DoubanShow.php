<?php
    /*
     * Plugin Name: 豆瓣秀 for WordPress
     * Version: 0.7
     * Plugin URI: http://reeze.cn/
     * Description: 在wordpress中显示你的豆瓣秀信息, 安装好后，请从小工具(widget)中添加到页面中
     * Author: reeze
     * Author URI: http://reeze.cn
     */
	 class DoubanShow extends WP_Widget
    {
         function DoubanShow(){
	         $widget_ops = array('classname'=>'widget_douban_show','description'=>'豆瓣秀');
	         $control_ops = array();
	         $this->WP_Widget(false,'豆瓣秀',$widget_ops,$control_ops);
         }

		function form($instance){
			$instance 	= wp_parse_args((array)$instance,array('title'=>'豆瓣秀','douban_id'=> 'reeze'));
			$title 		= htmlspecialchars($instance['title']);
			$douban_id 	= htmlspecialchars($instance['douban_id']);
			
			$is_collection 	= (string)$instance['show'] == 'collection' ? 'checked="checked"' : '';
			$is_dolist 		= (string)$instance['show'] == 'dolist' ? 'checked="checked"' : '';
			$is_wishlist 	= (string)$instance['show'] == 'wishlist' ? 'checked="checked"' : '';
			
			$cats = explode('|', (string)$instance['cat']);
			if(empty($cats)) {
				$cats = array('book', 'music', 'movie', 'site'); 
			}
			
			$have_cat_book 	= in_array('book', $cats) ? 'checked="checked"' : '';
			$have_cat_music = in_array('music', $cats) ? 'checked="checked"' : '';
			$have_cat_movie = in_array('movie', $cats) ? 'checked="checked"' : '';
			$have_cat_site 	= in_array('site', $cats) ? 'checked="checked"' : '';
			
			$is_select_lastest 	= (string)$instance['select'] == 'lastest' ? 'checked="checked"' : '';
			$is_select_favorite = (string)$instance['select'] == 'favorite' ? 'checked="checked"' : '';
			$is_select_random 	= (string)$instance['select'] == 'random' ? 'checked="checked"' : '';
			
			$picsize_small = (string)$instance['picsize']  == 'small' ? 'checked="checked"' : '';
			$picsize_medium = (string)$instance['picsize'] == 'medium' ? 'checked="checked"' : '';
			
			$hidelogo = (string)$instance['hidelogo'] == 'yes' ? 'checked="checked"' : '';
			$hideself = (string)$instance['hideself'] == 'yes' ? 'checked="checked"' : '';
			
			echo <<<OPTIONS
<table align="center">
	<tr>
		<td colspan="2">
			标题：<input type="text" value="{$instance['title']}" name="{$this->get_field_name('title')}" /><br /><br />
			豆瓣ID:<input id="{$this->get_field_id('douban_id')}" name="{$this->get_field_name('douban_id')}" type="text" value="{$douban_id}" /><br />
		</td>
	</tr>
    <tr><td width="40" valign="top">分类：</td><td>
    <label><input type="radio" $is_collection value="collection" name="{$this->get_field_name('show')}">我看(听)过的</label>
    <label><input type="radio" $is_dolist value="dolist" name="{$this->get_field_name('show')}">我在看(听)的</label>
    <label><input type="radio" $is_wishlist value="wishlist" name="{$this->get_field_name('show')}">我想看(听)的</label><br><br>
    

    <label><input type="checkbox" $have_cat_book value="book" name="{$this->get_field_name('cat_book')}">书</label>
    <label><input type="checkbox" $have_cat_music value="music" name="{$this->get_field_name('cat_music')}">音乐</label>
    <label><input type="checkbox" $have_cat_movie value="movie" name="{$this->get_field_name('cat_movie')}">电影</label>
    <label><input type="checkbox" $have_cat_site value="site" name="{$this->get_field_name('cat_site')}">Blog</label> <br><br>
    </td></tr>
    
    <tr><td valign="top">选取:</td><td>
    <label><input type="radio" $is_select_lastest value="latest" name="{$this->get_field_name('select')}">最新添加的</label>
    <label><input type="radio" $is_select_favorite value="favorite" name="{$this->get_field_name('select')}">推荐和力荐</label>
    <label><input type="radio" $is_select_random value="random" name="{$this->get_field_name('select')}">每次随机选择</label><br><br>
    </td></tr>
    <tr><td valign="top">显示</td><td valign="top" height="35">
     <label>共显示<input type="text" value="{$instance['num']}" maxlength="2" size="2" name="{$this->get_field_name('num')}">个</label>
    <label>每行<input type="text" value="{$instance['columns']}" maxlength="2" size="2" name="{$this->get_field_name('columns')}">个</label><br /><br />
    图片大小:
    <label><input type="radio" $picsize_small value="small" name="{$this->get_field_name('picsize')}">小</label>
    <label><input type="radio" $picsize_medium value="medium" name="{$this->get_field_name('picsize')}">中</label><br><br>
    <label><input type="checkbox" $hidelogo value='yes' name="{$this->get_field_name('hidelogo')}">隐藏douban.com图标</label><br><br>
    <label><input type="checkbox" $hideself value='yes' name="{$this->get_field_name('hideself')}">隐藏我的豆瓣主页链接</label><br><br>
    </td></tr>
    </table>
OPTIONS;
    	 }
	 
		 function update($new_instance,$old_instance){
			  $instance = $old_instance;
			  $instance['title'] = strip_tags(stripslashes($new_instance['title']));
			  $instance['douban_id'] = strip_tags(stripslashes($new_instance['douban_id']));
			  $instance['show'] = strip_tags(stripslashes($new_instance['show']));
			  
			  $cat_book = strip_tags(stripslashes($new_instance['cat_book']));
			  $cat_movie = strip_tags(stripslashes($new_instance['cat_movie']));
			  $cat_music = strip_tags(stripslashes($new_instance['cat_music']));
			  $cat_site = strip_tags(stripslashes($new_instance['cat_site']));
			  
			  $cats = array();
			  if($cat_book) {
			  	$cats[] = $cat_book;
			  }
			  if($cat_music) {
			  	$cats[] = $cat_music;
			  }
			  if($cat_movie) {
			  	$cats[] = $cat_movie;
			  }
			  if($cat_site) {
			  	$cats[] = $cat_site;
			  }
			  
			  if(empty($cats)) {
			  	$cats = array('book', 'music', 'movie', 'site');
			  }
			  
			  
			  $instance['cat'] = implode('|', $cats);
			  $instance['select'] = strip_tags(stripslashes($new_instance['select']));
			  $instance['num'] = strip_tags(stripslashes($new_instance['num']));
			  $instance['columns'] = strip_tags(stripslashes($new_instance['columns']));
			  $instance['picsize'] = strip_tags(stripslashes($new_instance['picsize']));
			  $instance['hidelogo'] = strip_tags(stripslashes($new_instance['hidelogo']));
			  $instance['hideself'] = strip_tags(stripslashes($new_instance['hideself']));
			  
			  return $instance;
		 }
		 
		function widget($args,$instance){
			  extract($args);
			  $title = apply_filters('widget_title',empty($instance['title']) ? '' : $instance['title']);
			  $douban_id = empty($instance['douban_id']) ? 'reeze' : $instance['douban_id'];
			  $show 	= empty($instance['show']) ? 'collection' : $instance['show'];
			  $cat  	= empty($instance['show']) ? 'book|music|movie|site' : $instance['cat'];
			  $select   = empty($instance['select']) ? 'lastest' : $instance['select'];
			  $num 		= empty($instance['num']) ? 8 : $instance['num'];
			  $columns 	= empty($instance['columns']) ? 2 : $instance['columns'];
			  $picsize 	= empty($instance['picsize']) ? 'small' : $instance['picsize'];
			  $hidelogo = empty($instance['hidelogo']) ? false : $instance['hidelogo'];
			  $hideself = empty($instance['hideself']) ? false : $instance['hideself'];

			  echo $before_widget;
			  echo $before_title . $title . $after_title;
			  echo $this->get_douban_show($douban_id, $show, $cat, $select, $num, $columns, $picsize, $hidelogo, $hideself);
			  echo $after_widget;
		 }
		 
		function get_douban_show($douban_id, $show='collection', $cat='', $select='lastest', $num=8, $columns=2, $picsize='small', $hidelogo=false, $hideself=false){
			$hidelogo = $hidelogo ? "&amp;hidelogo=yes" : '';
			$hideself = $hideself ? "&amp;hideself=yes" : '';
			$cat = $cat ? '&amp;cat=' . $cat : '&amp;cat=book|movie|music|site';
			$picsize = $picsize ? '&amp;picsize=' . $picsize : '';
			$select = $select ? '&amp;select=' . $select : '';
		
			return <<<SCRIPT
			<script type="text/javascript" src="http://www.douban.com/service/badge/$douban_id/?show={$show}&amp;n={$num}&amp;columns={$columns}{$select}{$picsize}{$cat}{$hidelogo}{$hideself}" ></script>
SCRIPT;
		}
 }
	
	
/*
** 注册小工具
*/
function douban_show_init(){
	 register_widget('DoubanShow');
}

add_action('widgets_init','douban_show_init');